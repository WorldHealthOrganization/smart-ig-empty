# Generic Personas - Empty IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Business Requirements**](business-requirements.md)
* **Generic Personas**

## Generic Personas

This page includes a depiction of end-users and related stakeholders as introduced in the WHO Digital Adaptation Kit for **[insert health domain here]**(link forthcoming).

The specific roles and demographic profile of the personas will vary depending on the setting, the generic personas are based on the WHO core competencies and credentials of different health worker personas.

### Targeted generic personas

The targeted personas for the **[insert health domain here]** Digital Adaptation Kit are health professionals operating in care settings that are able to provide the required essential interventions for **[insert health domain here]** delivery. Their key competences of are defined in the following table.

**Descriptions of key generic personas**

