# Sequence Diagrams - Empty IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Data Models and Exchange**](data-models-and-exchange.md)
* **Sequence Diagrams**

## Sequence Diagrams

# SMART

Feel free to modify this index page with your own awesome content!

