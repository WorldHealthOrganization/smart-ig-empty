# Changes - Empty IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Home**](index.md)
* **Changes**

## Changes

# SMART

Feel free to modify this index page with your own awesome content!

